package com.it.example.dans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DansApplicationTests {

	@Test
	void contextLoads() {
	}

}
